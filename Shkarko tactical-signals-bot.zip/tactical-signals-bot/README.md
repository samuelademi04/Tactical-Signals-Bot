# Tactical Signals Bot

Telegram bot që jep sinjale të thjeshta për çifte valutash me timeframe 30s.